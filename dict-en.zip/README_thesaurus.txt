en_GB, en_ZA, en_CA, en_AU use the WordNet thesaurus from the en_US dictionary.
